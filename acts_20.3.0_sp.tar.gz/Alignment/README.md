# Alignment package

This packages provides tools for detector geometry alignment.
Currently, the KalmanFitter-based alignment with internal minimization is implemented. 
In the future, the minimization will be done based on the external minimization package e.g. Millepede. 
